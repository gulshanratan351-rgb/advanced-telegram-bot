from pyrogram import Client
from config import API_ID, API_HASH, BOT_TOKEN

app = Client(
    "advanced_modifier_bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

import handlers.start
import handlers.frames
import handlers.channels
import handlers.protection
import handlers.forwarder

print("Bot Started Successfully")
app.run()

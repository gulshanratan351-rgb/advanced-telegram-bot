from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database import settings, channels
from styles import STYLES

@Client.on_message(filters.channel)
async def auto_forward(client, message):
    try:
        data = await channels.find_one({})
        if not data:
            return

        sources = data.get("sources", [])
        targets = data.get("targets", [])

        source_chat = message.chat.username
        if f"@{source_chat}" not in sources:
            return

        text = message.caption or message.text or ""

        user_settings = await settings.find_one({})
        if not user_settings:
            user_settings = {}

        header = user_settings.get("header", "")
        footer = user_settings.get("footer", "")
        style_name = user_settings.get("style", "minimal")

        style = STYLES.get(style_name, STYLES["minimal"])

        final_text = style.format(
            header=header,
            text=text,
            footer=footer
        )

        buttons = InlineKeyboardMarkup(
            [[InlineKeyboardButton("👁 View", callback_data="view")]]
        )

        for target in targets:
            if message.photo:
                await client.send_photo(
                    target,
                    message.photo.file_id,
                    caption=final_text,
                    has_spoiler=True,
                    reply_markup=buttons
                )
            else:
                await client.send_message(
                    target,
                    final_text,
                    reply_markup=buttons
                )

    except Exception as e:
        print(e)

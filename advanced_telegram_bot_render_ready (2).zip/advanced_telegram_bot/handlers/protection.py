from pyrogram import Client, filters

@Client.on_message(filters.service)
async def delete_service(client, message):
    try:
        await message.delete()
    except:
        pass

@Client.on_chat_join_request()
async def auto_approve(client, join_request):
    try:
        await join_request.approve()
    except:
        pass

from pyrogram import Client, filters

@Client.on_message(filters.command("start"))
async def start(client, message):
    await message.reply_text("✅ Advanced Telegram Modifier Bot Running")

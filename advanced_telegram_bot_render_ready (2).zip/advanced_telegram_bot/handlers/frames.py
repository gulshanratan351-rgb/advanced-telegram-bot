from pyrogram import Client, filters
from database import settings

@Client.on_message(filters.command("setheader"))
async def set_header(client, message):
    text = message.text.split(None, 1)[1]
    await settings.update_one(
        {"user_id": message.from_user.id},
        {"$set": {"header": text}},
        upsert=True
    )
    await message.reply_text("✅ Header Saved")

@Client.on_message(filters.command("setfooter"))
async def set_footer(client, message):
    text = message.text.split(None, 1)[1]
    await settings.update_one(
        {"user_id": message.from_user.id},
        {"$set": {"footer": text}},
        upsert=True
    )
    await message.reply_text("✅ Footer Saved")

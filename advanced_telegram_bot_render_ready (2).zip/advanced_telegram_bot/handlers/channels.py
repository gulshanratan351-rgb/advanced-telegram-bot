from pyrogram import Client, filters
from database import channels

@Client.on_message(filters.command("addsource"))
async def add_source(client, message):
    source = message.text.split(None, 1)[1]
    await channels.update_one(
        {"user_id": message.from_user.id},
        {"$addToSet": {"sources": source}},
        upsert=True
    )
    await message.reply_text("✅ Source Added")

@Client.on_message(filters.command("addtarget"))
async def add_target(client, message):
    target = message.text.split(None, 1)[1]
    await channels.update_one(
        {"user_id": message.from_user.id},
        {"$addToSet": {"targets": target}},
        upsert=True
    )
    await message.reply_text("✅ Target Added")

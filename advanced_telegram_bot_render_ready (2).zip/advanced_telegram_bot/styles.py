STYLES = {
    "minimal": "{header}\n\n{text}\n\n{footer}",
    "premium": "╔════════════════╗\n✨ PREMIUM POST ✨\n\n{text}\n\n{footer}\n╚════════════════╝",
    "movie": "━━━━━━━━━━\n🎬 {text}\n\n📢 {footer}\n━━━━━━━━━━",
    "neon": "⚡━━━━━━━━━━━━⚡\n{text}\n⚡━━━━━━━━━━━━⚡\n{footer}"
}

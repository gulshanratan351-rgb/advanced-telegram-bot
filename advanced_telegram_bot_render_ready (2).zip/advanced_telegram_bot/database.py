from motor.motor_asyncio import AsyncIOMotorClient
from config import MONGO_URI

client = AsyncIOMotorClient(MONGO_URI)
db = client.advanced_bot

users = db.users
channels = db.channels
settings = db.settings
schedules = db.schedules
